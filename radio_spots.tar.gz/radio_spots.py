import sys
import os

def debug(var):
	print var
	raw_input("Press Enter...")

# ====================================================================== #
# ====================================================================== #
class audio_labeler():
	labels = {}
	delim = ":"
	def __init__(self):
		lbls = [l.strip() for l in open("radio_spots.labels").readlines()]
		for l in lbls:
			self.labels[l.split(self.delim)[0]] = l.split(self.delim)[1].strip()

	def rename_file(self, url, directory):
		# e.g. http://www.example.com/file.mp3
		ext = "." + url.split(".")[-1]
		filename = url.split("/")[-1].replace(ext,"")
		return_dir = os.getcwd()
		if not return_dir.endswith(directory):
			os.chdir(directory)
		for l in self.labels:
			if l in filename:
				lbl = self.labels[l]
				try:
					os.rename(filename + ext, lbl + ext)
				except OSError: print("File " + filename + " does not exist and cannot be renamed.")
				break
		os.chdir(return_dir)
		return
# ====================================================================== #
# ====================================================================== #


def main():
	al = audio_labeler()
	al.rename_file('wolof7.wav','wolof/general')
	al.rename_file('wolof6.wav','wolof/general')

if __name__ == '__main__':
	main()



	

	

