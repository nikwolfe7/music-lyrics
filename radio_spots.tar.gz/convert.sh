# =======================================
#
# script to arrange every folder like so:
# folder [language-name] [sub-folder]
#
# =======================================
arr=( * )
for lang in "${arr[@]}"
do
	if [ -d "$lang/$1" ]; then
		echo "Entering '"$lang"' folder..."
		cd $lang/$1
		
		files=( * )
		for file in "${files[@]}"
		do
			if [ -f "$file" ]; then
				
				ext="${file##*.}"
				name="${file%.*}"
	
				# convert to wav
				if [ $ext == "mp3" ]; then
					if [ ! -f "$name.wav" ]; then
						echo "$file does not have a .wav counterpart!"
						echo "creating $name.wav..."
						ffmpeg -i "$file" "$name.wav"						
					fi

				# convert to mp3
				elif [ $ext == "wav" ]; then
					if [ ! -f "$name.mp3" ]; then
						echo "$file does not have a .mp3 counterpart!"
						echo "creating $name.mp3..."
						ffmpeg -i "$file" "$name.mp3"
					fi					
				fi
			fi
		done

		# get out of this directory!
		cd ../../
	fi
done
