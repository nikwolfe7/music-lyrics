filetypes = [".mp3",".wav"]

import os
import sys
import urllib2
from BeautifulSoup import BeautifulSoup
######################################
from radio_spots import audio_labeler
######################################

def debug(var):
	print var
	raw_input("Press Enter...")

al = audio_labeler()
live_lingua = sys.argv[1].strip()
subfolder = sys.argv[2].strip()
langs = [l.strip() for l in open("lang.list").readlines()]
base_url = "http://" + live_lingua.replace("http://","").split(os.sep)[0]

def rename_file(name):
	al.rename_file(name, os.getcwd())

def make_dir(name):
	try: os.stat(name)
	except: os.mkdir(name)

def arrange_audio(name,dirname="other"):
	retval = os.getcwd()
	make_dir(dirname)
	os.chdir(dirname)
	if dirname != "other":
		make_dir(subfolder)
		os.chdir(subfolder)
	if name.startswith(os.sep):
		name = base_url + name
	print "Retrieving " + name + "..."
	os.system("wget " + name.replace(" ", "%20"))
	#############################################
	rename_file(name)
	#############################################
	os.chdir(retval)

def go_get_stuff(soup):
	links = []
	use = False
	for a in soup('a'):
		try:
			href = a['href']
			for f in filetypes:
				if href.endswith(f):
					print "Found: " + href
					use = True
					break
		except: pass
		if not use: continue
		try:
			links.append(a['href'])
		except: continue
	for name in links:
		for l in langs:
			if l.lower() in name.lower():
				arrange_audio(name,l)

soup = BeautifulSoup(urllib2.urlopen(live_lingua).read())
go_get_stuff(soup)


